<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use app\users;

class UsersController extends Controller
{
    public function create()
    {
         return view('users.create');


    }

    public function store(Request $request)
    {
          
        $users = new \App\Models\User;
        $users->name = $request->name; 
        $users->email = $request->email;
        $users->password = $request->password;

        return "Usuario cadastrado com sucesso!";
    }

}
